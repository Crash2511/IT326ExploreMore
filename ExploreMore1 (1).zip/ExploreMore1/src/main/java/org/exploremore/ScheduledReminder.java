package org.exploremore;

import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import javax.swing.*;
import java.awt.*;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;


public class ScheduledReminder {
    JFrame frame = new JFrame();
    JLabel label = new JLabel("Send Email");
    JLabel fromLabel = new JLabel("From: ");
    JLabel toLabel = new JLabel("To: ");
    JLabel subjectLabel = new JLabel("Subject: ");
    JLabel textLabel = new JLabel("Text: ");
    JLabel timeLabel = new JLabel("Time to send: ");
    JTextField fromField = new JTextField();
    JTextField toField = new JTextField();
    JTextField subjectField = new JTextField();
    JTextArea textArea = new JTextArea();
    JTextField timeField = new JTextField();
    JButton sendButton = new JButton("Send Now");
    JButton scheduleButton = new JButton("Schedule Email");

    ScheduledReminder() {
        label.setBounds(100, 50, 20, 50);
        label.setFont(new Font(null, Font.PLAIN, 25));

        fromLabel.setBounds(50, 80, 80, 25);
        fromField.setBounds(120, 80, 200, 25);

        toLabel.setBounds(50, 120, 80, 25);
        toField.setBounds(120, 120, 200, 25);

        subjectLabel.setBounds(20, 20, 20, 20);
        subjectField.setBounds(200, 100, 40, 20);

        textLabel.setBounds(50, 200, 80, 25);
        textArea.setBounds(120, 200, 200, 100);

        timeLabel.setBounds(50, 320, 80, 25);
        timeField.setBounds(140, 320, 20, 25);

        sendButton.setBounds(50, 360, 100, 25);
        sendButton.addActionListener(e -> sendEmail());

        scheduleButton.setBounds(220, 360, 130, 25);
        scheduleButton.addActionListener(e -> scheduleEmail());

        frame.add(label);
        frame.add(fromLabel);
        frame.add(fromField);
        frame.add(toLabel);
        frame.add(toField);
        frame.add(subjectLabel);
        frame.add(subjectField);
        frame.add(textLabel);
        frame.add(textArea);
        frame.add(timeLabel);
        frame.add(timeField);
        frame.add(sendButton);
        frame.add(scheduleButton);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(420, 420);
        frame.setLayout(null);
        frame.setVisible(true);
    }

    private void sendEmail() {
        String from = fromField.getText();
        String to = toField.getText();
        String subject = subjectField.getText();
        String text = textArea.getText();

        JavaMailSender mailSender = createMailSender();

        SimpleMailMessage mailMessage = new SimpleMailMessage();
        mailMessage.setFrom(from);
        mailMessage.setTo(to);
        mailMessage.setSubject(subject);
        mailMessage.setText(text);

        mailSender.send(mailMessage);

        JOptionPane.showMessageDialog(frame, "Email sent successfully!");
    }

    private void scheduleEmail() {
        String from = fromField.getText();
        String to = toField.getText();
        String subject = subjectField.getText();
        String text = textArea.getText();
        String time = timeField.getText();
        Date date = new Date();
        long delay = 0;
        try {
            int hours = Integer.parseInt(time.substring(0, 2));
            int minutes = Integer.parseInt(time.substring(3, 5));
            int seconds = Integer.parseInt(time.substring(6));
            date.setHours(hours);
            date.setMinutes(minutes);
            date.setSeconds(seconds);

            long currentTime = System.currentTimeMillis();
            long scheduledTime = date.getTime();
            delay = scheduledTime - currentTime;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame, "Invalid time format. Please enter time in hh:mm:ss format.");
            return;
        }

        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            public void run() {
                JavaMailSender mailSender = createMailSender();

                SimpleMailMessage mailMessage = new SimpleMailMessage();
                mailMessage.setFrom(from);
                mailMessage.setTo(to);
                mailMessage.setSubject(subject);
                mailMessage.setText(text);

                mailSender.send(mailMessage);

                JOptionPane.showMessageDialog(frame, "Email sent successfully!");
            }
        }, delay);

        JOptionPane.showMessageDialog(frame, "Email scheduled successfully!");
    }

    private JavaMailSender createMailSender() {
        JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
        mailSender.setHost("smtp.gmail.com");
        mailSender.setPort(587);

        mailSender.setUsername("SamsonOkunola10@gmail.com"); // your Gmail username
        mailSender.setPassword("ancaajndesyezdey"); // your Gmail password

        mailSender.getJavaMailProperties().setProperty("mail.smtp.auth", "true");
        mailSender.getJavaMailProperties().setProperty("mail.smtp.starttls.enable", "true");

        return mailSender;
    }

    public static void main(String[] args) {
        new ScheduledReminder();
    }
}

